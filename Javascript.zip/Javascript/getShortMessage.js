function getShortMessage(arr) {
    const words= [];
    words.forEach(function(element) {
        if(words.filter(element=> element.length <50))
         console.log(element);
      });

  }